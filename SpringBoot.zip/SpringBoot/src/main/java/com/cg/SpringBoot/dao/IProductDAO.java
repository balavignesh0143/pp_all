package com.cg.SpringBoot.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.SpringBoot.bean.Products;

@Repository
public interface IProductDAO extends JpaRepository<Products, Long> {

@Query("from Products where id=:c")
Optional<Products> findById(@Param("c") long id);

//@Query("from Products where id=:s")
//void deleteById(@Param("s") String id); 

@Query("from Products where price >= :p")
Optional<Products> findByPrice(@Param("p") long price);
}
