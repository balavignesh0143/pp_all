package com.cg.SpringBoot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBoot.bean.Products;
import com.cg.SpringBoot.dao.IProductDAO;
import com.cg.SpringBoot.prodexception.ProductsException;


@Service
public class ProductServiceIMPL implements IProductService {

	@Autowired
	IProductDAO productDAO;

	@Override
	public List<Products> addProduct(Products pro) throws ProductsException {
		try {
			long price = pro.getPrice() * pro.getQuantity();
			pro.setTotal_price(price);
			productDAO.save(pro);
			return productDAO.findAll();
		} catch (Exception e) {
			throw new ProductsException(e.getMessage());
		}
	}

	@Override
	public Products getProductById(long id) throws ProductsException {
		try {
			return productDAO.findById(id).get();
		} catch (Exception e) {
			throw new ProductsException(e.getMessage());
		}
	}

	@Override
	public List<Products> getAllProducts() throws ProductsException {
		try {
			return productDAO.findAll();
		} catch (Exception e) {
			throw new ProductsException(e.getMessage());
		}
	}

	@Override
	public void deleteProduct(long id) throws ProductsException {
		try {
			productDAO.deleteById(id);
		} catch (Exception e) {
			throw new ProductsException(e.getMessage());
		}
	}

	@Override
	public List<Products> updateProduct(long id, Products bo) throws ProductsException {
		try {
			Optional<Products> optional = productDAO.findById(id);
			if (optional.isPresent()) {
				Products product = optional.get();
				product.setName(bo.getName());
				product.setModel(bo.getModel());
				product.setPrice(bo.getPrice());
				product.setQuantity(bo.getQuantity());
				product.setTotal_price(bo.getPrice() * bo.getQuantity());
				productDAO.save(product);
				return getAllProducts();
			} else {
				throw new ProductsException("Product with Id" + id + " is not  existing please enter an valid id ");
			}
		} catch (Exception e) {
			throw new ProductsException(e.getMessage());

		}
	}

	@Override
	public Products getProductByPrice(long price) {

	  return productDAO.findByPrice(price).get();
	}
}
