package com.cg.SpringBoot.service;

import java.util.List;

import com.cg.SpringBoot.bean.Products;
import com.cg.SpringBoot.prodexception.ProductsException;
public interface IProductService {

	public List<Products> addProduct(Products pro) throws ProductsException;
	public Products getProductById(long id) throws ProductsException;
	public void deleteProduct (long id) throws ProductsException;
	public List<Products> getAllProducts() throws ProductsException;
	public List<Products> updateProduct(long id, Products bo) throws ProductsException;
	public Products getProductByPrice(long price) throws ProductsException;

}
