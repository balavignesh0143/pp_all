package com.cg.SpringBoot.prodexception;

@SuppressWarnings("serial")
public class ProductsException extends Exception
{
	public ProductsException()
	{
		super();
	}
	public ProductsException(String msg)
	{
		super(msg);
	}
	
}
