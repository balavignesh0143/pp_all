package com.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.bean.TransferDetails;
import com.bean.UserDetails;
import com.service.Calculation;

public class Store implements StoreInter {
	
	UserDetails ud;
	TransferDetails td;
	Calculation c;
	
	Scanner sc=new Scanner(System.in);
	
	HashMap<Long,UserDetails> hm=new HashMap<Long,UserDetails>();
	HashMap<TransferDetails,Long> hm1=new HashMap<TransferDetails,Long>();
	
	public void addDetails(UserDetails ud)
	{
		this.ud=ud;
		hm.put(ud.getAccNo(),ud);
		System.out.println(hm);
	}
	
	public void transferDetails(TransferDetails td)
	{
		this.td=td;
		
		System.out.println(hm1);
	}

	public HashMap<Long,UserDetails> hm()
	{
		return hm;
	}
	
	public HashMap<TransferDetails,Long> hm1()
	{
		return hm1;
	}

	
	
	public void createAccount(UserDetails ud) 
	{
		hm.put(ud.getAccNo(),ud);
		ud=(UserDetails)hm.get(ud.getAccNo());
	}

	public double showBalance(long accNo)
	{
		ud=(UserDetails)hm.get(accNo);
		if(ud==null)
		{
			throw new AccountNotFoundException("Invalid account number...");
		}
		else
		{
			double bal=ud.getBalance();
			return bal;
		}
	}

	public double depositBalance(long accNo,double deposit) 
	{
		ud=(UserDetails)hm.get(accNo);
		if(ud==null)
		{
			throw new AccountNotFoundException("Invalid account number...");
		}
		else
		{
			double bal=ud.getBalance();
			double d=bal+deposit;
			ud.setBalance(d);
			hm.put(accNo,ud);
			
			TransferDetails td=new TransferDetails();
			td.setAccNoFrom(accNo);
			td.setTransferAmt(deposit);
			td.setTransType("deposit");
			DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
			LocalDateTime now=LocalDateTime.now();
			td.setDateOfTrans(dt.format(now));
			td.setBalance(d);
			hm1.put(td,(long) deposit);
			return d;
		}
	}
	
	public double withdrawBalance(long accNo, double withdraw) 
	{
		ud=(UserDetails)hm.get(accNo);
		if(ud==null)
		{
			throw new AccountNotFoundException("Invalid account number...");
		}
		else
		{
			double bal=ud.getBalance();
			if(bal<withdraw)
			{
				throw new InSufficientFundsException("Insufficient funds!!!");
			}
			else
			{
				double d=bal-withdraw;
				ud.setBalance(d);
				hm.put(accNo,ud);
				
				TransferDetails td=new TransferDetails();
				td.setAccNoFrom(accNo);
				td.setTransferAmt(withdraw);
				td.setTransType("withdraw");
				DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
				LocalDateTime now=LocalDateTime.now();
				td.setDateOfTrans(dt.format(now));
				td.setBalance(d);
				hm1.put(td,(long) withdraw);
				
				return d;
			}
		}
	}

	public double fundTransfer(long accNo,long accNo1,double balance) 
	{
		ud=(UserDetails)hm.get(accNo);
		UserDetails ud1=(UserDetails)hm.get(accNo1);
		if(ud==null||ud1==null)
		{
			throw new AccountNotFoundException("Invalid account number...");
		}
		else
		{
			double bal=ud.getBalance();
			ud=(UserDetails)hm.get(accNo1);
			double bal1=ud.getBalance();
			bal=bal-balance;
			bal1=bal1+balance;
			ud.setBalance(bal);
			hm.put(accNo,ud);
			ud.setBalance(bal1);
			hm.put(accNo1,ud);
			TransferDetails td=new TransferDetails();
			td.setAccNoFrom(accNo);
			td.setAccNoTo(accNo1);
			td.setTransferAmt(balance);
			td.setTransId(1000);//dummy
			td.setBalance(bal);
			td.setTransType("Transfer");
			DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
			LocalDateTime now=LocalDateTime.now();
			td.setDateOfTrans(dt.format(now));
			hm1.put(td,(long) balance);
			return bal;
		}
		
	}
	
	public List<TransferDetails> printTrans(long accNo)
	{
		ud=(UserDetails)hm.get(accNo);
		if(ud==null)
		{
			throw new AccountNotFoundException("Invalid account number...");
		}
		else
		{
			Set<TransferDetails> s=hm1.keySet();
			ArrayList<TransferDetails> al=new ArrayList<>(s);
			return al;
		}
		
		
	}
}
